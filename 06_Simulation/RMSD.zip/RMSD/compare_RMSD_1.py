
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

# =====================================================
# INPUT FILES
# =====================================================

files = {
    "Protein backbone | Eicosatrienoic acid methyl ester":
        "protein_backbone_rmsd_1.xvg",

    "Protein backbone | 1-Phenyl-1-butene":
        "protein_backbone_rmsd_2.xvg",

    "SfruGOBP1 + Eicosatrienoic acid methyl ester":
        "protein_ligand_complex_rmsd_1.xvg",

    "SfruGOBP1 + 1-Phenyl-1-butene":
        "protein_ligand_complex_rmsd_2.xvg"
}

# Four distinct colours
colors = [
    "#2166AC",  # Blue
    "#D6604D",  # Red
    "#1B9E77",  # Green
    "#984EA3"   # Purple
]

# =====================================================
# READ XVG FILE
# =====================================================

def read_xvg(filename):

    data = []

    with open(filename, "r") as f:
        for line in f:

            line = line.strip()

            if not line or line.startswith(("#", "@")):
                continue

            values = line.split()

            try:
                data.append([
                    float(values[0]),
                    float(values[1])
                ])
            except (ValueError, IndexError):
                continue

    if not data:
        raise ValueError(f"No data found in {filename}")

    return pd.DataFrame(data, columns=["Time", "RMSD"])


# =====================================================
# CREATE ONE COMBINED GRAPH
# =====================================================

plt.figure(figsize=(13, 7))

for (label, filename), color in zip(files.items(), colors):

    df = read_xvg(filename)

    plt.plot(
        df["Time"],
        df["RMSD"],
        color=color,
        linewidth=1.5,
        label=label
    )

# =====================================================
# GRAPH FORMATTING
# =====================================================

plt.xlabel("Simulation Time (ns)", fontsize=14, fontweight="bold")
plt.ylabel("RMSD (nm)", fontsize=14, fontweight="bold")

plt.title(
    "Comparative RMSD Analysis of SfruGOBP1–Ligand Complexes",
    fontsize=16,
    fontweight="bold",
    pad=15
)

plt.xlim(0, 100)
plt.xticks(np.arange(0, 101, 10))

plt.grid(
    True,
    linestyle="--",
    linewidth=0.6,
    alpha=0.4
)

plt.legend(
    fontsize=10,
    loc="best",
    frameon=True
)

ax = plt.gca()
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

plt.tight_layout()

# =====================================================
# SAVE HIGH-RESOLUTION FIGURES
# =====================================================

plt.savefig(
    "SfruGOBP1_All_Four_RMSD.png",
    dpi=600,
    bbox_inches="tight"
)

plt.savefig(
    "SfruGOBP1_All_Four_RMSD.pdf",
    bbox_inches="tight"
)

plt.show()

print("Combined four-curve RMSD graph generated successfully.")

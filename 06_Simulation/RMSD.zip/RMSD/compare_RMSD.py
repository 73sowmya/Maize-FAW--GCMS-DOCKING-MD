
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

# ============================================================
# 1. INPUT FILES
# ============================================================

data_dir = Path(".")

files = {
    "Protein": {
        "Ligand 1": "protein_backbone_rmsd_1.xvg",
        "Ligand 2": "protein_backbone_rmsd_2.xvg"
    },
    "Ligand": {
        "Ligand 1": "ligand_rmsd_1.xvg",
        "Ligand 2": "ligand_rmsd_2.xvg"
    },
    "Protein-Ligand Complex": {
        "Ligand 1": "protein_ligand_complex_rmsd_1.xvg",
        "Ligand 2": "protein_ligand_complex_rmsd_2.xvg"
    }
}

labels = {
    "Ligand 1": "Eicosatrienoic acid methyl ester",
    "Ligand 2": "1-Phenyl-1-butene"
}

# ============================================================
# 2. READ GROMACS XVG FILES
# ============================================================

def read_xvg(filename):

    data = []

    with open(filename, "r") as file:
        for line in file:

            line = line.strip()

            # Ignore GROMACS metadata and comments
            if not line or line.startswith(("#", "@")):
                continue

            values = line.split()

            try:
                time = float(values[0])
                rmsd = float(values[1])
                data.append([time, rmsd])

            except (ValueError, IndexError):
                continue

    if not data:
        raise ValueError(f"No numerical data found in {filename}")

    df = pd.DataFrame(data, columns=["Time_ns", "RMSD_nm"])

    return df


# ============================================================
# 3. LOAD ALL SIX FILES
# ============================================================

results = {}

for category, simulations in files.items():

    results[category] = {}

    for simulation, filename in simulations.items():

        filepath = data_dir / filename

        if not filepath.exists():
            raise FileNotFoundError(f"Missing file: {filepath}")

        results[category][simulation] = read_xvg(filepath)

        print(f"Loaded: {filename}")


# ============================================================
# 4. CREATE THREE-PANEL COMPARATIVE RMSD GRAPH
# ============================================================

plt.rcParams.update({
    "font.family": "Arial",
    "font.size": 11,
    "axes.labelsize": 12,
    "axes.titlesize": 13,
    "legend.fontsize": 9,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "axes.linewidth": 1.2
})

fig, axes = plt.subplots(
    3, 1,
    figsize=(11, 13),
    sharex=True
)

colors = {
    "Ligand 1": "#2166AC",
    "Ligand 2": "#D6604D"
}

titles = [
    "(A) Protein Backbone RMSD",
    "(B) Ligand RMSD",
    "(C) Protein-Ligand Complex RMSD"
]

for ax, (category, simulations), title in zip(
    axes, results.items(), titles
):

    for simulation, df in simulations.items():

        ax.plot(
            df["Time_ns"],
            df["RMSD_nm"],
            label=labels[simulation],
            color=colors[simulation],
            linewidth=1.4,
            alpha=0.9
        )

    ax.set_title(title, fontweight="bold", loc="left")
    ax.set_ylabel("RMSD (nm)")
    ax.set_xlim(0, 100)

    ax.grid(
        True,
        linestyle="--",
        linewidth=0.5,
        alpha=0.5
    )

    ax.legend(frameon=False, loc="best")

    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

axes[-1].set_xlabel("Simulation Time (ns)")
axes[-1].set_xticks(np.arange(0, 101, 10))

fig.suptitle(
    "Comparative RMSD Analysis of SfruGOBP1-Ligand Complexes",
    fontsize=15,
    fontweight="bold",
    y=0.995
)

plt.tight_layout(rect=[0, 0, 1, 0.98])

# Save publication-quality figures
plt.savefig(
    "SfruGOBP1_Comparative_RMSD.png",
    dpi=600,
    bbox_inches="tight"
)

plt.savefig(
    "SfruGOBP1_Comparative_RMSD.pdf",
    bbox_inches="tight"
)

plt.show()


# ============================================================
# 5. CALCULATE RMSD SUMMARY STATISTICS
# ============================================================

summary = []

for category, simulations in results.items():

    for simulation, df in simulations.items():

        summary.append({
            "Analysis": category,
            "Ligand": labels[simulation],
            "Mean_RMSD_nm": df["RMSD_nm"].mean(),
            "Median_RMSD_nm": df["RMSD_nm"].median(),
            "SD_RMSD_nm": df["RMSD_nm"].std(),
            "Maximum_RMSD_nm": df["RMSD_nm"].max()
        })

summary_df = pd.DataFrame(summary)

summary_df.to_csv(
    "SfruGOBP1_RMSD_Summary.csv",
    index=False
)

print("\nRMSD Summary Statistics:")
print(summary_df.round(4).to_string(index=False))

print("\nAll figures and summary statistics saved successfully.")

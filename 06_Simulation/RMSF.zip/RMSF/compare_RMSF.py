
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

# ==========================================================
# 1. INPUT FILES
# ==========================================================

files = {
    "Protein | Eicosatrienoic acid methyl ester":
        "protein_rmsf_1.xvg",

    "Protein | 1-Phenyl-1-butene":
        "protein_rmsf_2.xvg",

    "Complex | Eicosatrienoic acid methyl ester":
        "complex_rmsf_1.xvg",

    "Complex | 1-Phenyl-1-butene":
        "complex_rmsf_2.xvg"
}

colors = {
    "Protein | Eicosatrienoic acid methyl ester": "#2166AC",
    "Protein | 1-Phenyl-1-butene": "#D6604D",
    "Complex | Eicosatrienoic acid methyl ester": "#1B9E77",
    "Complex | 1-Phenyl-1-butene": "#984EA3"
}

# ==========================================================
# 2. READ GROMACS XVG FILES
# ==========================================================

def read_xvg(filename):

    data = []

    with open(filename, "r") as f:

        for line in f:

            line = line.strip()

            if not line or line.startswith(("#", "@")):
                continue

            values = line.split()

            try:
                residue = float(values[0])
                rmsf = float(values[1])

                data.append([residue, rmsf])

            except (ValueError, IndexError):
                continue

    if not data:
        raise ValueError(f"No numerical data found in {filename}")

    return pd.DataFrame(
        data,
        columns=["Residue", "RMSF"]
    )


# ==========================================================
# 3. LOAD ALL FOUR FILES
# ==========================================================

results = {}

for label, filename in files.items():

    path = Path(filename)

    if not path.exists():
        raise FileNotFoundError(f"Missing file: {filename}")

    results[label] = read_xvg(path)

    print(f"Loaded: {filename}")
    print("Number of data points:", len(results[label]))


# ==========================================================
# 4. CREATE COMPARATIVE RMSF GRAPH
# ==========================================================

plt.rcParams.update({
    "font.family": "Arial",
    "font.size": 11,
    "axes.labelsize": 13,
    "axes.titlesize": 15,
    "legend.fontsize": 10,
    "axes.linewidth": 1.2
})

fig, ax = plt.subplots(figsize=(14, 7))

for label, df in results.items():

    ax.plot(
        df["Residue"],
        df["RMSF"],
        color=colors[label],
        linewidth=1.5,
        label=label,
        alpha=0.9
    )

# ==========================================================
# 5. GRAPH FORMATTING
# ==========================================================

ax.set_title(
    "Comparative RMSF Analysis of SfruGOBP1-Ligand Complexes",
    fontsize=16,
    fontweight="bold",
    pad=15
)

ax.set_xlabel(
    "Amino Acid Residue Number",
    fontweight="bold"
)

ax.set_ylabel(
    "RMSF (nm)",
    fontweight="bold"
)

ax.set_xlim(left=1)

ax.grid(
    True,
    linestyle="--",
    linewidth=0.6,
    alpha=0.4
)

ax.legend(
    loc="upper right",
    frameon=True,
    fontsize=10
)

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

plt.tight_layout()

# ==========================================================
# 6. SAVE HIGH-RESOLUTION FIGURES
# ==========================================================

plt.savefig(
    "SfruGOBP1_Comparative_RMSF.png",
    dpi=600,
    bbox_inches="tight"
)

plt.savefig(
    "SfruGOBP1_Comparative_RMSF.pdf",
    bbox_inches="tight"
)

plt.show()


# ==========================================================
# 7. RMSF SUMMARY STATISTICS
# ==========================================================

summary = []

for label, df in results.items():

    summary.append({
        "Analysis": label,
        "Mean_RMSF_nm": df["RMSF"].mean(),
        "Median_RMSF_nm": df["RMSF"].median(),
        "SD_RMSF_nm": df["RMSF"].std(),
        "Maximum_RMSF_nm": df["RMSF"].max()
    })

summary_df = pd.DataFrame(summary)

summary_df.to_csv(
    "SfruGOBP1_RMSF_Summary.csv",
    index=False
)

print("\nRMSF Summary Statistics:")
print(summary_df.round(4).to_string(index=False))

print("\nAll RMSF figures and statistics saved successfully.")


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

# =====================================================
# 1. INPUT FILES
# =====================================================

files = {
    "SfruGOBP1 Protein":
        "protein_rg_1.xvg",

    "SfruGOBP1 + Eicosatrienoic acid methyl ester":
        "complex_rg_1.xvg",

    "SfruGOBP1 + 1-Phenyl-1-butene":
        "complex_rg_2.xvg"
}

colors = {
    "SfruGOBP1 Protein": "#2166AC",
    "SfruGOBP1 + Eicosatrienoic acid methyl ester": "#D62728",
    "SfruGOBP1 + 1-Phenyl-1-butene": "#2CA02C"
}

# =====================================================
# 2. READ XVG FILES
# =====================================================

def read_xvg(filename):

    data = []

    with open(filename, "r") as f:

        for line in f:

            line = line.strip()

            if not line or line.startswith(("#", "@")):
                continue

            values = line.split()

            try:
                time_ps = float(values[0])
                rg_nm = float(values[1])

                data.append([time_ps, rg_nm])

            except (ValueError, IndexError):
                continue

    if not data:
        raise ValueError(f"No numerical data found: {filename}")

    return pd.DataFrame(
        data,
        columns=["Time_ps", "Rg_nm"]
    )


# =====================================================
# 3. LOAD DATA
# =====================================================

results = {}

for label, filename in files.items():

    if not Path(filename).exists():
        raise FileNotFoundError(f"Missing file: {filename}")

    df = read_xvg(filename)
    results[label] = df

    print(f"{label}: {len(df)} frames")
    print(
        f"Time range: {df['Time_ps'].min():.1f} - "
        f"{df['Time_ps'].max():.1f} ps"
    )


# =====================================================
# 4. CREATE THREE-CURVE Rg GRAPH
# =====================================================

plt.rcParams.update({
    "font.family": "Arial",
    "font.size": 12,
    "axes.labelsize": 14,
    "axes.titlesize": 17,
    "legend.fontsize": 10,
    "axes.linewidth": 1.3
})

fig, ax = plt.subplots(figsize=(14, 7))

for label, df in results.items():

    ax.plot(
        df["Time_ps"],
        df["Rg_nm"],
        color=colors[label],
        linewidth=0.75,
        alpha=0.95,
        label=label
    )

# =====================================================
# 5. GRAPH FORMATTING
# =====================================================

ax.set_title(
    "Comparative Radius of Gyration Analysis",
    fontsize=17,
    fontweight="bold",
    pad=15
)

ax.set_xlabel(
    "Time (ps)",
    fontsize=14,
    fontweight="bold"
)

ax.set_ylabel(
    "Radius of Gyration (nm)",
    fontsize=14,
    fontweight="bold"
)

ax.set_xlim(0, 100000)
ax.set_xticks(np.arange(0, 100001, 10000))

ax.grid(
    True,
    linestyle="--",
    linewidth=0.5,
    alpha=0.35
)

ax.legend(
    loc="best",
    frameon=True,
    fontsize=10
)

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

plt.tight_layout()

# =====================================================
# 6. SAVE FIGURES
# =====================================================

plt.savefig(
    "SfruGOBP1_Rg_Three_Curves.png",
    dpi=600,
    bbox_inches="tight"
)

plt.savefig(
    "SfruGOBP1_Rg_Three_Curves.pdf",
    bbox_inches="tight"
)

plt.show()


# =====================================================
# 7. SUMMARY STATISTICS
# =====================================================

summary = []

for label, df in results.items():

    summary.append({
        "System": label,
        "Mean_Rg_nm": df["Rg_nm"].mean(),
        "Median_Rg_nm": df["Rg_nm"].median(),
        "SD_Rg_nm": df["Rg_nm"].std(),
        "Minimum_Rg_nm": df["Rg_nm"].min(),
        "Maximum_Rg_nm": df["Rg_nm"].max()
    })

summary_df = pd.DataFrame(summary)

summary_df.to_csv(
    "SfruGOBP1_Rg_Three_Curves_Summary.csv",
    index=False
)

print("\nRg Summary Statistics:")
print(summary_df.round(4).to_string(index=False))

print("\nThree-curve Rg graph generated successfully.")
